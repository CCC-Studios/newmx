// =============================================================================
// Prompt赤 — Popup logic
// =============================================================================

(async function () {
  'use strict';

  const DEFAULTS = {
    enabled: true,
    autoPrependTable: true,
    showSavingsToast: true,
    mapName: 'phrase_glyph_map_path1_en_b3_v005_rev4',
  };

  // -------------------------------------------------------------------------
  // Map probe — verify the selected map JSON exists in the bundle
  // -------------------------------------------------------------------------
  async function probeMap(mapName) {
    try {
      const url = chrome.runtime.getURL(`maps/${mapName}.json`);
      const resp = await fetch(url);
      if (!resp.ok) return { ok: false, count: 0 };
      const data = await resp.json();
      const count = data.phrase_to_family_and_glyph
        ? Object.keys(data.phrase_to_family_and_glyph).length
        : 0;
      return { ok: count > 0, count };
    } catch {
      return { ok: false, count: 0 };
    }
  }

  function setStatus(text, kind) {
    const dot = document.getElementById('status-dot');
    const txt = document.getElementById('status-text');
    txt.textContent = text;
    dot.classList.remove('ok', 'error');
    if (kind) dot.classList.add(kind);
  }

  async function refreshStatus(mapName) {
    setStatus('Probing map…', null);
    const probe = await probeMap(mapName);
    if (probe.ok) {
      setStatus(`Map: ${mapName} · ${probe.count} phrases`, 'ok');
    } else {
      setStatus(`Map "${mapName}.json" missing or invalid`, 'error');
    }
  }

  // -------------------------------------------------------------------------
  // Wire up controls
  // -------------------------------------------------------------------------
  const stored = await chrome.storage.sync.get(DEFAULTS);
  const settings = { ...DEFAULTS, ...stored };

  const enabled = document.getElementById('enabled');
  const autoPrependTable = document.getElementById('autoPrependTable');
  const showSavingsToast = document.getElementById('showSavingsToast');
  const mapName = document.getElementById('mapName');

  enabled.checked = settings.enabled;
  autoPrependTable.checked = settings.autoPrependTable;
  showSavingsToast.checked = settings.showSavingsToast;

  // Make sure stored mapName exists in the dropdown; otherwise add it
  if (![...mapName.options].some(o => o.value === settings.mapName)) {
    const opt = document.createElement('option');
    opt.value = settings.mapName;
    opt.textContent = `${settings.mapName} (custom)`;
    mapName.appendChild(opt);
  }
  mapName.value = settings.mapName;

  enabled.addEventListener('change', () => {
    chrome.storage.sync.set({ enabled: enabled.checked });
  });
  autoPrependTable.addEventListener('change', () => {
    chrome.storage.sync.set({ autoPrependTable: autoPrependTable.checked });
  });
  showSavingsToast.addEventListener('change', () => {
    chrome.storage.sync.set({ showSavingsToast: showSavingsToast.checked });
  });
  mapName.addEventListener('change', async () => {
    await chrome.storage.sync.set({ mapName: mapName.value });
    refreshStatus(mapName.value);
  });

  refreshStatus(settings.mapName);
})();
