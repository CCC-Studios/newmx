# Phrase maps

Bundled with v0.2.0:

```
phrase_glyph_map_path1_en_b3_v005_rev4.json   ← default loaded by Prompt赤 v0.2.0
```

This is the rev4 codec — 37 families, ~3100 mappings — including:
- WEB_SEARCH (像) and REPORT_BACK (信) from v005-rev2
- CONTINUE_APPROVAL (れ) from v005-rev4
- Universal `for me` suffix expansion
- 18 lossy in-LANG entries evicted

If you want to swap in a different map (e.g. a future v005-rev5), just drop
the JSON file in this directory and update `mapName` in the popup.
