// =============================================================================
// Prompt赤 — Content Script v0.2.1
// Multi-platform support: Claude + ChatGPT + Gemini
// =============================================================================
// Injects a 赤 button near the host site's send button.
// On click: read editor → encode via NewMx Path 1 (v005-rev4 + cli5 pipeline)
//   → replace editor content.
// First message of a conversation auto-prepends the decode table.
//
// Platform detection by hostname (claude.ai / chatgpt.com / gemini.google.com).
// Each platform has its own adapter with selectors for editor + send button +
// message containers. Fallback: nearest-bottom visible textarea/contenteditable.
// =============================================================================

(function () {
  'use strict';

  const ENC = window.__newmx_encoder;
  const DEC = window.__newmx_decoder;
  const T = window.__newmx_tokenizer;

  const PLATFORM = detectPlatform();

  // -------------------------------------------------------------------------
  // STATE
  // -------------------------------------------------------------------------
  let MAP = null;
  let COMPILED = null;
  let DECODE_TABLE = null;

  let SETTINGS = {
    enabled: true,
    autoPrependTable: true,
    showSavingsToast: true,
    mapName: 'phrase_glyph_map_path1_en_b3_v005_rev4'
  };

  let TOAST_EL = null;
  let TOAST_TIMER = null;
  let OBSERVER = null;
  let INJECT_THROTTLE = null;

  // -------------------------------------------------------------------------
  // PLATFORM DETECTION
  // -------------------------------------------------------------------------
  function detectPlatform() {
    const host = location.hostname.toLowerCase();

    if (host === 'claude.ai' || host.endsWith('.claude.ai')) {
      return 'claude';
    }

    if (
      host === 'chatgpt.com' ||
      host.endsWith('.chatgpt.com') ||
      host === 'chat.openai.com' ||
      host.endsWith('.chat.openai.com')
    ) {
      return 'chatgpt';
    }

    if (
      host === 'gemini.google.com' ||
      host.endsWith('.gemini.google.com') ||
      host === 'bard.google.com' ||
      host.endsWith('.bard.google.com')
    ) {
      return 'gemini';
    }

    return 'unknown';
  }

  function platformLabel() {
    switch (PLATFORM) {
      case 'claude': return 'Claude';
      case 'chatgpt': return 'ChatGPT';
      case 'gemini': return 'Gemini';
      default: return 'this site';
    }
  }

  // -------------------------------------------------------------------------
  // SETTINGS
  // -------------------------------------------------------------------------
  async function loadSettings() {
    try {
      const stored = await chrome.storage.sync.get(SETTINGS);
      SETTINGS = { ...SETTINGS, ...stored };
    } catch (err) {
      console.warn('[Prompt赤] Settings load failed; using defaults', err);
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;

    for (const k of Object.keys(changes)) {
      if (k in SETTINGS) SETTINGS[k] = changes[k].newValue;
    }

    if ('mapName' in changes) {
      loadMap();
    }

    if ('enabled' in changes) {
      if (SETTINGS.enabled) {
        scheduleInject();
      } else {
        removeButtons();
      }
    }
  });

  // -------------------------------------------------------------------------
  // MAP LOADING
  // -------------------------------------------------------------------------
  async function loadMap() {
    try {
      const url = chrome.runtime.getURL(`maps/${SETTINGS.mapName}.json`);
      const resp = await fetch(url);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);

      MAP = await resp.json();

      if (!MAP.phrase_to_family_and_glyph) {
        throw new Error('Invalid map: missing phrase_to_family_and_glyph');
      }

      COMPILED = ENC.compilePatterns(MAP);
      DECODE_TABLE = DEC.buildDecodeTable(MAP);

      console.log(
        `[Prompt赤] Loaded map "${SETTINGS.mapName}": ` +
        `${Object.keys(MAP.phrase_to_family_and_glyph).length} phrases, ` +
        `${DECODE_TABLE.familyCount} families, ${DECODE_TABLE.structCount} structural`
      );

      return true;
    } catch (err) {
      console.error('[Prompt赤] Map load failed:', err);
      MAP = null;
      COMPILED = null;
      DECODE_TABLE = null;
      return false;
    }
  }

  // -------------------------------------------------------------------------
  // PLATFORM ADAPTERS
  // -------------------------------------------------------------------------
  const ADAPTERS = {
    claude: {
      editorSelectors: [
        'div[contenteditable="true"][role="textbox"]',
        'div.ProseMirror[contenteditable="true"]',
        'div[contenteditable="true"]',
      ],
      sendButtonSelectors: [
        'button[aria-label="Send Message"]',
        'button[aria-label*="Send" i]',
        'fieldset button[type="submit"]',
        'button[type="submit"]',
      ],
      messageSelectors: [
        '[data-test-render-count]',
        '[data-testid="user-message"]',
        '.font-claude-message',
        '[data-test-id="message"]',
      ],
      insertion: 'before-send',
    },

    chatgpt: {
      editorSelectors: [
        '#prompt-textarea',
        'textarea[data-testid="prompt-textarea"]',
        'textarea[placeholder]',
        'textarea',
        'div[contenteditable="true"]#prompt-textarea',
        'div[contenteditable="true"][data-testid="prompt-textarea"]',
        'div[contenteditable="true"][role="textbox"]',
        'div[contenteditable="true"]',
      ],
      sendButtonSelectors: [
        'button[data-testid="send-button"]',
        'button[aria-label="Send prompt"]',
        'button[aria-label*="Send" i]',
        'form button[type="submit"]',
        'button[type="submit"]',
      ],
      messageSelectors: [
        '[data-message-author-role]',
        '[data-testid^="conversation-turn"]',
        'article',
      ],
      insertion: 'before-send',
    },

    gemini: {
      editorSelectors: [
        'rich-textarea div[contenteditable="true"]',
        'div[contenteditable="true"][role="textbox"]',
        'div.ql-editor[contenteditable="true"]',
        'textarea',
        'div[contenteditable="true"]',
      ],
      sendButtonSelectors: [
        'button[aria-label="Send message"]',
        'button[aria-label*="Send" i]',
        'button.send-button',
        'button[type="submit"]',
      ],
      messageSelectors: [
        'user-query',
        'model-response',
        '.conversation-container user-query',
        '.conversation-container model-response',
      ],
      insertion: 'before-send',
    },
  };

  function adapter() {
    return ADAPTERS[PLATFORM] || ADAPTERS.chatgpt;
  }

  function queryFirst(selectors, root = document) {
    for (const selector of selectors) {
      try {
        const el = root.querySelector(selector);
        if (el) return el;
      } catch {
        // Ignore unsupported selectors on older engines.
      }
    }
    return null;
  }

  function findEditor() {
    const direct = queryFirst(adapter().editorSelectors);
    if (direct) return direct;

    // Last-resort fallback: choose the visible editable nearest the bottom.
    const candidates = [...document.querySelectorAll('textarea, [contenteditable="true"]')]
      .filter(isVisible)
      .sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top);

    return candidates[0] || null;
  }

  function findSendButton() {
    const direct = queryFirst(adapter().sendButtonSelectors);
    if (direct && isVisible(direct)) return direct;

    // Last-resort fallback: visible button near the bottom with send-ish metadata.
    const buttons = [...document.querySelectorAll('button')]
      .filter(isVisible)
      .filter((btn) => {
        const label = [
          btn.getAttribute('aria-label'),
          btn.getAttribute('data-testid'),
          btn.title,
          btn.textContent,
        ].filter(Boolean).join(' ').toLowerCase();

        return /send|submit|arrow|paper/.test(label);
      })
      .sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top);

    return buttons[0] || null;
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return (
      rect.width > 0 &&
      rect.height > 0 &&
      style.visibility !== 'hidden' &&
      style.display !== 'none' &&
      style.opacity !== '0'
    );
  }

  function isFirstMessageInConversation() {
    const selectors = adapter().messageSelectors.join(', ');
    const messages = selectors ? document.querySelectorAll(selectors) : [];

    // Filter out prompt editor wrappers that sometimes match broad selectors.
    const realMessages = [...messages].filter((el) => {
      if (!isVisible(el)) return false;
      if (el.closest('.newmx-btn')) return false;
      if (el.matches('textarea, [contenteditable="true"]')) return false;
      return true;
    });

    return realMessages.length === 0;
  }

  // -------------------------------------------------------------------------
  // EDITOR READ / WRITE
  // -------------------------------------------------------------------------
  function getEditorText(editor) {
    if (!editor) return '';

    if (editor.tagName === 'TEXTAREA' || editor.tagName === 'INPUT') {
      return editor.value || '';
    }

    return editor.innerText || editor.textContent || '';
  }

  function setEditorText(editor, newText) {
    if (!editor) return;

    if (editor.tagName === 'TEXTAREA' || editor.tagName === 'INPUT') {
      setNativeInputValue(editor, newText);
      return;
    }

    setContentEditableText(editor, newText);
  }

  function setNativeInputValue(el, value) {
    el.focus();

    const proto = el.tagName === 'TEXTAREA'
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;

    const valueSetter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    const ownValueSetter = Object.getOwnPropertyDescriptor(el, 'value')?.set;

    if (ownValueSetter && ownValueSetter !== valueSetter) {
      ownValueSetter.call(el, value);
    } else if (valueSetter) {
      valueSetter.call(el, value);
    } else {
      el.value = value;
    }

    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'insertText',
      data: value,
    }));

    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function setContentEditableText(editor, value) {
    editor.focus();

    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(editor);
    sel.removeAllRanges();
    sel.addRange(range);

    // Works well for ProseMirror/Quill-style editors because it goes through
    // the editor's input pipeline instead of directly mutating DOM nodes.
    const ok = document.execCommand('insertText', false, value);

    if (!ok) {
      editor.textContent = value;
      editor.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        inputType: 'insertText',
        data: value,
      }));
    }
  }

  // -------------------------------------------------------------------------
  // ENCODE FLOW
  // -------------------------------------------------------------------------
  function compressAndReplace() {
    if (!SETTINGS.enabled) {
      showToast('Prompt赤 is disabled in settings', 'warn');
      return;
    }

    if (!MAP || !COMPILED || !DECODE_TABLE) {
      showToast('NewMx map not loaded yet — reload the page or check settings', 'error');
      return;
    }

    const editor = findEditor();
    if (!editor) {
      showToast(`Could not find ${platformLabel()} input editor`, 'error');
      return;
    }

    const raw = getEditorText(editor);
    if (!raw.trim()) {
      showToast('Editor is empty', 'warn');
      return;
    }

    const result = ENC.encodeText(raw, MAP, COMPILED);
    let finalText = result.encoded;

    let tablePrepended = false;
    if (SETTINGS.autoPrependTable && isFirstMessageInConversation()) {
      finalText = `${DECODE_TABLE.text}\n\n${result.encoded}`;
      tablePrepended = true;
    }

    setEditorText(editor, finalText);

    if (SETTINGS.showSavingsToast) {
      showSavings(result, tablePrepended);
    }
  }

  function showSavings(result, tablePrepended) {
    const tableTokens = tablePrepended ? T.tokenCount(DECODE_TABLE.text) : 0;
    const promptDelta = result.stats.totalDelta;
    const pct = result.stats.pctSaved.toFixed(1);

    let msg = `赤 ${result.stats.rawTokens} → ${result.stats.encodedTokens} tok (−${pct}%)`;

    if (tablePrepended) {
      const netDelta = promptDelta - tableTokens;
      msg += ` · +${tableTokens} table one-time`;
      msg += netDelta >= 0 ? ` · net +${netDelta}` : ` · net ${netDelta}`;
    }

    showToast(msg, promptDelta > 0 ? 'ok' : 'warn');
  }

  // -------------------------------------------------------------------------
  // BUTTON INJECTION
  // -------------------------------------------------------------------------
  function createButton() {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'newmx-btn';
    btn.title = `Compress with NewMx赤 Path 1 on ${platformLabel()}`;
    btn.setAttribute('aria-label', 'Compress prompt with NewMx赤');
    btn.dataset.newmxPlatform = PLATFORM;

    const label = document.createElement('span');
    label.className = 'newmx-label';
    label.textContent = '赤';

    btn.appendChild(label);

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      compressAndReplace();
    });

    return btn;
  }

  function injectButton(sendBtn) {
    if (!sendBtn || !sendBtn.parentElement) return;
    if (!SETTINGS.enabled) return;

    const parent = sendBtn.parentElement;
    if (parent.querySelector(':scope > .newmx-btn')) return;

    const btn = createButton();

    try {
      parent.insertBefore(btn, sendBtn);
    } catch {
      parent.appendChild(btn);
    }
  }

  function removeButtons() {
    document.querySelectorAll('.newmx-btn').forEach((btn) => btn.remove());
  }

  function tryInject() {
    if (!SETTINGS.enabled) return;
    const sendBtn = findSendButton();
    if (sendBtn) injectButton(sendBtn);
  }

  function scheduleInject() {
    if (INJECT_THROTTLE) return;

    INJECT_THROTTLE = setTimeout(() => {
      INJECT_THROTTLE = null;
      tryInject();
    }, 150);
  }

  // -------------------------------------------------------------------------
  // TOAST
  // -------------------------------------------------------------------------
  function showToast(text, kind = 'ok') {
    if (!TOAST_EL) {
      TOAST_EL = document.createElement('div');
      TOAST_EL.className = 'newmx-toast';
      document.body.appendChild(TOAST_EL);
    }

    TOAST_EL.textContent = text;
    TOAST_EL.dataset.kind = kind;
    TOAST_EL.classList.add('newmx-toast-show');

    if (TOAST_TIMER) clearTimeout(TOAST_TIMER);
    TOAST_TIMER = setTimeout(() => {
      TOAST_EL.classList.remove('newmx-toast-show');
    }, 3000);
  }

  // -------------------------------------------------------------------------
  // OBSERVER
  // -------------------------------------------------------------------------
  function startObserver() {
    if (OBSERVER) OBSERVER.disconnect();

    OBSERVER = new MutationObserver(() => {
      if (!document.querySelector('.newmx-btn')) {
        scheduleInject();
      }
    });

    OBSERVER.observe(document.body, { childList: true, subtree: true });
  }

  // -------------------------------------------------------------------------
  // BOOT
  // -------------------------------------------------------------------------
  async function boot() {
    if (PLATFORM === 'unknown') {
      console.warn('[Prompt赤] Unsupported platform:', location.hostname);
      return;
    }

    if (!ENC || !DEC || !T) {
      console.error('[Prompt赤] Missing NewMx globals. Check manifest script order.');
      return;
    }

    await loadSettings();
    const ok = await loadMap();

    if (!ok) {
      console.warn('[Prompt赤] Boot incomplete — map missing. Drop a phrase map JSON into maps/ and reload.');
    }

    scheduleInject();
    startObserver();

    console.log(`[Prompt赤] v0.2.1 active on ${platformLabel()}`);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
